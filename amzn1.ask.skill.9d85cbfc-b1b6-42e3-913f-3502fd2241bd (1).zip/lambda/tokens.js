const TOKEN = 'text';

module.exports = TOKEN;